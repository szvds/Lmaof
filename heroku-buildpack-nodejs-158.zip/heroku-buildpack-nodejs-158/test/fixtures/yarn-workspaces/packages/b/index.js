const { double } = require('a')

console.log(double(2));