const double = (num) => num * 2

module.exports = {
  double
}